El‑Dawy Static Site — RFQ Form
- Works on any static host using mailto fallback.
- To enable JSON POST, deploy api/quote.js on Vercel and set data-endpoint="/api/quote" on the <form>. 